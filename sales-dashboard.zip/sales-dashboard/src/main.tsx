import React from 'react';
import ReactDOM from 'react-dom/client';
import SalesDashboard from './components/SalesDashboard';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')!).render(
    <React.StrictMode>
        <SalesDashboard />
    </React.StrictMode>
);
