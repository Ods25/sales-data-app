import React, { useEffect, useState } from 'react';
import axios from 'axios';

interface Sale {
    id: number;
    customerName: string;
    region: string;
    product: string;
    revenue: number;
}

const SalesDashboard: React.FC = () => {
    const [sales, setSales] = useState<Sale[]>([]);
    const [sortColumn, setSortColumn] = useState<string>('customerName');
    const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

    useEffect(() => {
        axios.get('http://localhost:8080/sales')
            .then(response => setSales(response.data))
            .catch(error => console.error('Error fetching sales data:', error));
    }, []);

    const handleSort = (column: keyof Sale) => {
        const newSortOrder = sortColumn === column && sortOrder === 'asc' ? 'desc' : 'asc';
        setSortColumn(column);
        setSortOrder(newSortOrder);

        const sortedData = [...sales].sort((a, b) => {
            if (column === 'revenue') {
                return newSortOrder === 'asc'
                    ? a[column] - b[column]
                    : b[column] - a[column];
            }
            const valA = a[column].toString().toLowerCase();
            const valB = b[column].toString().toLowerCase();
            return newSortOrder === 'asc'
                ? valA.localeCompare(valB)
                : valB.localeCompare(valA);
        });

        setSales(sortedData);
    };

    return (
        <div
            style={{
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'center',
                alignItems: 'center',
                height: '100vh',
                textAlign: 'center',
                backgroundColor: '#f8f9fa', // Light background
                fontFamily: 'Arial, sans-serif',
            }}
        >
            <h1 style={{ marginBottom: '20px', fontSize: '2.5rem', color: '#333' }}>
                Sales Dashboard
            </h1>
            <div
                style={{
                    border: '1px solid #ccc',
                    padding: '20px',
                    height: '500px',
                    width: '80%',
                    maxWidth: '800px',
                    backgroundColor: 'darkslategray',
                    overflowY: 'scroll',
                    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
                    borderRadius: '10px',
                }}
            >
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                    <thead>
                    <tr>
                        <th
                            style={{ cursor: 'pointer', padding: '10px', textAlign: 'left', borderBottom: '1px solid #ddd' }}
                            onClick={() => handleSort('customerName')}
                        >
                            Customer {sortColumn === 'customerName' && (sortOrder === 'asc' ? '↑' : '↓')}
                        </th>
                        <th
                            style={{ cursor: 'pointer', padding: '10px', textAlign: 'left', borderBottom: '1px solid #ddd' }}
                            onClick={() => handleSort('region')}
                        >
                            Region {sortColumn === 'region' && (sortOrder === 'asc' ? '↑' : '↓')}
                        </th>
                        <th
                            style={{ cursor: 'pointer', padding: '10px', textAlign: 'left', borderBottom: '1px solid #ddd' }}
                            onClick={() => handleSort('product')}
                        >
                            Product {sortColumn === 'product' && (sortOrder === 'asc' ? '↑' : '↓')}
                        </th>
                        <th
                            style={{ cursor: 'pointer', padding: '10px', textAlign: 'left', borderBottom: '1px solid #ddd' }}
                            onClick={() => handleSort('revenue')}
                        >
                            Revenue {sortColumn === 'revenue' && (sortOrder === 'asc' ? '↑' : '↓')}
                        </th>
                    </tr>
                    </thead>
                    <tbody>
                    {sales.map((sale) => (
                        <tr key={sale.id} style={{ borderBottom: '1px solid #eee' }}>
                            <td style={{ padding: '10px', textAlign: 'left' }}>{sale.customerName}</td>
                            <td style={{ padding: '10px', textAlign: 'left' }}>{sale.region}</td>
                            <td style={{ padding: '10px', textAlign: 'left' }}>{sale.product}</td>
                            <td style={{ padding: '10px', textAlign: 'left' }}>${sale.revenue.toFixed(2)}</td>
                        </tr>
                    ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default SalesDashboard;
